# UsahoDen v8.78 — Perbaikan Restore Backup

Perbaikan utama:
- Pemilih file Android mengikuti tipe file yang diminta oleh halaman aplikasi.
- Restore Data dapat memilih file backup JSON (`.json`) dari penyimpanan HP.
- Pemilihan gambar produk tetap memakai filter gambar.
- Versi aplikasi dinaikkan menjadi 8.78.

Source Android berada pada folder `app/`.

Catatan: APK tetap harus dibangun dan diuji pada perangkat sebelum dinyatakan berhasil.
