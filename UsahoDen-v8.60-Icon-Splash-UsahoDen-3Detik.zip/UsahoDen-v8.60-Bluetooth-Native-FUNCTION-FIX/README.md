UsahoDen v8.60 - Bluetooth Native + latest HTML functions
