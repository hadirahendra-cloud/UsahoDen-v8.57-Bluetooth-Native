UsahoDen v9.04 - Header 3 Baris, Menu Compact, dan Ruang Scroll Bawah Tambahan.

Perubahan: padding bawah drawer navigasi ditambah agar menu terakhir dapat digulir dengan ruang yang cukup di atas bilah navigasi Android. Logo, header, dan fungsi menu dipertahankan.

ZIP source; APK belum dibangun atau diuji.
