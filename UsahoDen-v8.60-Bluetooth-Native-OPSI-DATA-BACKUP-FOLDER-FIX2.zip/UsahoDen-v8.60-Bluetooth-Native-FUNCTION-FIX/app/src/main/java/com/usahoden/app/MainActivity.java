package com.usahoden.app;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Toast;

import org.json.JSONArray;

import java.io.OutputStream;
import java.io.ByteArrayInputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends Activity {
    private WebView webView;
    private BluetoothAdapter adapter;
    private static final int REQ_BT = 701;
    private static final int REQ_BACKUP_FOLDER = 702;
    private String pendingBackupJson = null;
    private String pendingBackupName = "UsahoDen-Backup.json";
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        adapter = BluetoothAdapter.getDefaultAdapter();

        // Android 15 / target 35 uses edge-to-edge by default.  Do NOT let the
        // WebView occupy the physical system-bar areas.  Instead the WebView
        // itself is laid out between the status bar and navigation bar.
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        }
        getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);
        getWindow().setNavigationBarColor(android.graphics.Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(0);

        android.widget.FrameLayout root = new android.widget.FrameLayout(this);
        root.setBackgroundColor(android.graphics.Color.rgb(0, 174, 239));

        webView = new WebView(this);
        android.widget.FrameLayout.LayoutParams webLp =
                new android.widget.FrameLayout.LayoutParams(
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT);
        root.addView(webView, webLp);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new NativeBridge(), "UsahoDenNative");

        // Use margins rather than WebView padding. This is important because
        // the UsahoDen HTML has fixed/sticky header elements; padding can still
        // allow those elements to draw underneath Android system bars.
        webView.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = 0, bottom = 0, left = 0, right = 0;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(
                        WindowInsets.Type.statusBars()
                                | WindowInsets.Type.navigationBars()
                                | WindowInsets.Type.displayCutout());
                top = bars.top;
                bottom = bars.bottom;
                left = bars.left;
                right = bars.right;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
                left = insets.getSystemWindowInsetLeft();
                right = insets.getSystemWindowInsetRight();
            }

            android.widget.FrameLayout.LayoutParams lp =
                    (android.widget.FrameLayout.LayoutParams) v.getLayoutParams();
            if (lp.topMargin != top || lp.bottomMargin != bottom ||
                    lp.leftMargin != left || lp.rightMargin != right) {
                lp.topMargin = top;
                lp.bottomMargin = bottom;
                lp.leftMargin = left;
                lp.rightMargin = right;
                v.setLayoutParams(lp);
            }
            return insets;
        });

        setContentView(root);
        requestBluetoothPermission();
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void requestBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, REQ_BT);
        }
    }

    private boolean hasConnectPermission() {
        return Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private List<BluetoothDevice> pairedPrinters() {
        List<BluetoothDevice> out = new ArrayList<>();
        if (adapter == null || !hasConnectPermission()) return out;
        try {
            for (BluetoothDevice d : adapter.getBondedDevices()) {
                String n = d.getName();
                if (n != null && !n.trim().isEmpty()) out.add(d);
            }
        } catch (SecurityException ignored) {}
        return out;
    }

    public class NativeBridge {
        @JavascriptInterface public String getPairedPrinters() {
            JSONArray a = new JSONArray();
            for (BluetoothDevice d : pairedPrinters()) {
                try { a.put(d.getName()); } catch (Exception ignored) {}
            }
            return a.toString();
        }

        @JavascriptInterface public boolean isBluetoothReady() {
            return adapter != null && adapter.isEnabled() && hasConnectPermission();
        }

        @JavascriptInterface public void printText(final String text) {
            runOnUiThread(() -> new Thread(() -> doPrint(text == null ? "" : text, "")).start());
        }

        @JavascriptInterface public void printTextToPrinter(final String text, final String printerName) {
            runOnUiThread(() -> new Thread(() -> doPrint(text == null ? "" : text, printerName == null ? "" : printerName)).start());
        }

        @JavascriptInterface public void backupDataToFolder(final String json, final String fileName) {
            runOnUiThread(() -> {
                pendingBackupJson = json == null ? "{}" : json;
                pendingBackupName = (fileName == null || fileName.trim().isEmpty()) ? "UsahoDen-Backup.json" : fileName;
                try {
                    // ACTION_CREATE_DOCUMENT lets the user choose the destination folder
                    // and creates the backup file there directly.
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, pendingBackupName);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(intent, REQ_BACKUP_FOLDER);
                } catch (Exception e) {
                    toast("Pemilih folder tidak tersedia");
                }
            });
        }

        @JavascriptInterface public void showMessage(final String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }
    }

    private void doPrint(String text, String printerName) {
        if (adapter == null) { toast("Bluetooth tidak tersedia"); return; }
        if (!hasConnectPermission()) { toast("Izin Bluetooth belum diberikan"); return; }
        if (!adapter.isEnabled()) { toast("Aktifkan Bluetooth terlebih dahulu"); return; }
        List<BluetoothDevice> devices = pairedPrinters();
        if (devices.isEmpty()) { toast("Belum ada printer Bluetooth yang dipasangkan"); return; }
        BluetoothDevice chosen = devices.get(0);
        if (printerName != null && !printerName.trim().isEmpty()) {
            for (BluetoothDevice d : devices) if (printerName.equals(d.getName())) { chosen = d; break; }
        }
        BluetoothSocket socket = null;
        try {
            socket = chosen.createRfcommSocketToServiceRecord(SPP_UUID);
            socket.connect();
            OutputStream out = socket.getOutputStream();
            out.write(new byte[]{0x1B,0x40});
            byte[] data;
            try { data = text.replace("\r\n","\n").getBytes(Charset.forName("windows-1252")); }
            catch (Exception e) { data = text.getBytes(); }
            out.write(data);
            out.write(new byte[]{0x0A,0x0A,0x0A});
            out.flush();
            toast("Struk dikirim ke " + chosen.getName());
        } catch (Exception e) {
            toast("Gagal terhubung ke " + chosen.getName() + ". Pastikan printer sudah dipasangkan.");
        } finally {
            if (socket != null) try { socket.close(); } catch (Exception ignored) {}
        }
    }

    private void toast(String s) { runOnUiThread(() -> Toast.makeText(MainActivity.this, s, Toast.LENGTH_LONG).show()); }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_BACKUP_FOLDER) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            pendingBackupJson = null;
            toast("Backup dibatalkan");
            return;
        }
        Uri fileUri = data.getData();
        try {
            try {
                getContentResolver().takePersistableUriPermission(
                        fileUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION |
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } catch (Exception ignored) {}

            try (OutputStream out = getContentResolver().openOutputStream(fileUri, "w")) {
                if (out == null) throw new Exception("Gagal membuka file");
                out.write((pendingBackupJson == null ? "{}" : pendingBackupJson)
                        .getBytes(java.nio.charset.StandardCharsets.UTF_8));
                out.flush();
            }

            toast("Backup tersimpan: " + pendingBackupName);
        } catch (Exception e) {
            toast("Gagal menyimpan backup");
        } finally {
            pendingBackupJson = null;
            pendingBackupName = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
