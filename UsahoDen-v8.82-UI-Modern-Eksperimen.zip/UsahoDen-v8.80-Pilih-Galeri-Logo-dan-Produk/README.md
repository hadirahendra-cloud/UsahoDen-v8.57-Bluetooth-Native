# UsahoDen v8.82 - UI Modern Eksperimen

Paket uji untuk mencoba tampilan index.html modern di WebView UsahoDen.

Catatan: index.html ini merupakan prototipe visual dan belum terhubung penuh ke seluruh bridge/fitur native UsahoDen. Gunakan untuk uji tampilan saja. Jangan hapus APK lama atau data penting; buat backup terlebih dahulu.
