package com.usahoden.app;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;

import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends Activity {
    private WebView webView;
    private BluetoothAdapter adapter;
    private static final int REQ_BT = 701;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        adapter = BluetoothAdapter.getDefaultAdapter();
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new NativeBridge(), "UsahoDenNative");
        setContentView(webView);
        requestBluetoothPermission();
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void requestBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, REQ_BT);
        }
    }

    private boolean hasConnectPermission() {
        return Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private List<BluetoothDevice> pairedPrinters() {
        List<BluetoothDevice> out = new ArrayList<>();
        if (adapter == null || !hasConnectPermission()) return out;
        try {
            for (BluetoothDevice d : adapter.getBondedDevices()) {
                String n = d.getName();
                if (n != null && !n.trim().isEmpty()) out.add(d);
            }
        } catch (SecurityException ignored) {}
        return out;
    }

    public class NativeBridge {
        @JavascriptInterface public String getPairedPrinters() {
            JSONArray a = new JSONArray();
            for (BluetoothDevice d : pairedPrinters()) {
                try { a.put(d.getName()); } catch (Exception ignored) {}
            }
            return a.toString();
        }

        @JavascriptInterface public boolean isBluetoothReady() {
            return adapter != null && adapter.isEnabled() && hasConnectPermission();
        }

        @JavascriptInterface public void printText(final String text) {
            runOnUiThread(() -> new Thread(() -> doPrint(text == null ? "" : text, "")).start());
        }

        @JavascriptInterface public void printTextToPrinter(final String text, final String printerName) {
            runOnUiThread(() -> new Thread(() -> doPrint(text == null ? "" : text, printerName == null ? "" : printerName)).start());
        }

        @JavascriptInterface public void showMessage(final String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }
    }

    private void doPrint(String text, String printerName) {
        if (adapter == null) { toast("Bluetooth tidak tersedia"); return; }
        if (!hasConnectPermission()) { toast("Izin Bluetooth belum diberikan"); return; }
        if (!adapter.isEnabled()) { toast("Aktifkan Bluetooth terlebih dahulu"); return; }
        List<BluetoothDevice> devices = pairedPrinters();
        if (devices.isEmpty()) { toast("Belum ada printer Bluetooth yang dipasangkan"); return; }
        BluetoothDevice chosen = devices.get(0);
        if (printerName != null && !printerName.trim().isEmpty()) {
            for (BluetoothDevice d : devices) if (printerName.equals(d.getName())) { chosen = d; break; }
        }
        BluetoothSocket socket = null;
        try {
            socket = chosen.createRfcommSocketToServiceRecord(SPP_UUID);
            socket.connect();
            OutputStream out = socket.getOutputStream();
            out.write(new byte[]{0x1B,0x40});
            byte[] data;
            try { data = text.replace("\r\n","\n").getBytes(Charset.forName("windows-1252")); }
            catch (Exception e) { data = text.getBytes(); }
            out.write(data);
            out.write(new byte[]{0x0A,0x0A,0x0A});
            out.flush();
            toast("Struk dikirim ke " + chosen.getName());
        } catch (Exception e) {
            toast("Gagal terhubung ke " + chosen.getName() + ". Pastikan printer sudah dipasangkan.");
        } finally {
            if (socket != null) try { socket.close(); } catch (Exception ignored) {}
        }
    }

    private void toast(String s) { runOnUiThread(() -> Toast.makeText(MainActivity.this, s, Toast.LENGTH_LONG).show()); }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
