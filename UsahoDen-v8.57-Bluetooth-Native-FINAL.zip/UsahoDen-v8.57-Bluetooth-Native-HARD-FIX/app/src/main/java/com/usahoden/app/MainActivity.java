package com.usahoden.app;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private WebView web;
    private static final int REQ_BT = 56;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new BluetoothBridge(), "AndroidBluetooth");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        requestBluetoothPermissions();
    }

    private void requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            List<String> p = new ArrayList<>();
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
                p.add(Manifest.permission.BLUETOOTH_CONNECT);
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
                p.add(Manifest.permission.BLUETOOTH_SCAN);
            if (!p.isEmpty()) requestPermissions(p.toArray(new String[0]), REQ_BT);
        }
    }

    private boolean hasBtPermission() {
        return Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private BluetoothAdapter adapter() { return BluetoothAdapter.getDefaultAdapter(); }

    private void ui(String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
    }

    private class BluetoothBridge {
        @JavascriptInterface public String isNative() { return "true"; }

        @JavascriptInterface public String getPairedPrinters() {
            try {
                if (!hasBtPermission()) return "[]";
                BluetoothAdapter a = adapter();
                if (a == null) return "[]";
                JSONArray arr = new JSONArray();
                for (BluetoothDevice d : a.getBondedDevices()) {
                    String name = d.getName();
                    if (name != null && !name.trim().isEmpty()) {
                        JSONObject o = new JSONObject();
                        o.put("name", name);
                        o.put("address", d.getAddress());
                        arr.put(o);
                    }
                }
                return arr.toString();
            } catch (Exception e) { return "[]"; }
        }

        @JavascriptInterface public void printBluetooth(final String printerName, final String text) {
            if (!hasBtPermission()) {
                ui("Izinkan Perangkat di sekitar untuk UsahoDen, lalu coba lagi.");
                requestBluetoothPermissions();
                return;
            }
            new Thread(() -> doPrint(printerName, text == null ? "" : text)).start();
        }

        private void doPrint(String requestedName, String text) {
            BluetoothSocket socket = null;
            try {
                BluetoothAdapter a = adapter();
                if (a == null) { ui("HP tidak memiliki Bluetooth."); return; }
                if (!a.isEnabled()) { ui("Bluetooth HP belum aktif."); return; }

                String wanted = requestedName == null ? "" : requestedName.trim();
                BluetoothDevice target = null;
                Set<BluetoothDevice> paired = a.getBondedDevices();

                for (BluetoothDevice d : paired) {
                    String n = d.getName();
                    if (!wanted.isEmpty() && wanted.equalsIgnoreCase(n == null ? "" : n.trim())) {
                        target = d; break;
                    }
                }
                if (target == null) {
                    for (BluetoothDevice d : paired) {
                        String n = d.getName();
                        if (n != null && (n.toUpperCase().contains("RPP02N") || n.toUpperCase().contains("RPP") || n.toUpperCase().contains("PRINTER") || n.toUpperCase().contains("POS"))) {
                            target = d; break;
                        }
                    }
                }
                if (target == null && paired.size() == 1) target = paired.iterator().next();
                if (target == null) { ui("RPP02N belum dipair di Bluetooth HP."); return; }

                a.cancelDiscovery();
                String targetName = target.getName() == null ? "RPP02N" : target.getName();
                Exception last = null;

                // Thermal ESC/POS printers commonly use classic Bluetooth SPP.
                try {
                    socket = target.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                    socket.connect();
                } catch (Exception e1) {
                    last = e1;
                    try { if (socket != null) socket.close(); } catch (Exception ignored) {}
                    socket = null;
                    try {
                        socket = target.createRfcommSocketToServiceRecord(SPP_UUID);
                        socket.connect();
                    } catch (Exception e2) {
                        last = e2;
                        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
                        socket = null;
                        try {
                            java.lang.reflect.Method m = target.getClass().getMethod("createRfcommSocket", int.class);
                            socket = (BluetoothSocket)m.invoke(target, 1);
                            socket.connect();
                        } catch (Exception e3) { last = e3; }
                    }
                }

                if (socket == null || !socket.isConnected()) {
                    ui("RPP02N terdeteksi, tetapi koneksi Bluetooth gagal. Hapus pair RPP02N lalu pair ulang.");
                    return;
                }

                OutputStream out = socket.getOutputStream();
                byte[] data = buildEscPos(text);
                out.write(data);
                out.flush();
                try { Thread.sleep(150); } catch (InterruptedException ignored) {}
                ui("Struk dikirim ke " + targetName);
            } catch (SecurityException e) {
                ui("Izin Bluetooth belum diberikan ke UsahoDen.");
            } catch (Exception e) {
                ui("Koneksi RPP02N gagal. Pastikan printer menyala dan sudah pair.");
            } finally {
                if (socket != null) try { socket.close(); } catch (Exception ignored) {}
            }
        }

        private byte[] buildEscPos(String text) throws Exception {
            // Keep the existing receipt text. Thermal printers are generally more
            // reliable with a single-byte code page than UTF-8 for basic Indonesian text.
            String clean = text == null ? "" : text.replace("\u0000", "");
            byte[] body;
            try { body = clean.getBytes(Charset.forName("Windows-1252")); }
            catch (Exception e) { body = clean.getBytes(Charset.forName("UTF-8")); }
            byte[] init = new byte[]{0x1B,0x40};
            byte[] feed = new byte[]{0x0A,0x0A,0x0A,0x0A};
            byte[] cut = new byte[]{0x1D,0x56,0x00};
            byte[] all = new byte[init.length + body.length + feed.length + cut.length];
            int p=0;
            System.arraycopy(init,0,all,p,init.length); p+=init.length;
            System.arraycopy(body,0,all,p,body.length); p+=body.length;
            System.arraycopy(feed,0,all,p,feed.length); p+=feed.length;
            System.arraycopy(cut,0,all,p,cut.length);
            return all;
        }
    }
}
