UsahoDen v8.86 Premium Futuristic

Basis source: v8.81 Etalase Nama-Harga Rapi. Perubahan ini memodernisasi CSS tampilan dan menaikkan versionName/versionCode, dengan mempertahankan HTML/JavaScript dan fitur yang ada. Build APK melalui GitHub Actions. Prototipe index.html terpisah tidak menggantikan fungsi aplikasi.


## v8.87 — Fix Pengaturan Scroll
- Bottom navigation diperkecil.
- Form Pengaturan Toko diberi ruang scroll bawah agar tombol Simpan dan Batal dapat dijangkau.
- Identitas aplikasi, ikon, Beranda premium, dan navigasi Pengaturan dipertahankan.
