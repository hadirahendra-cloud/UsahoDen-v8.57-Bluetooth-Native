# UsahoDen v8.57 Bluetooth Native

Project Android Native untuk menjalankan UsahoDen HTML di WebView dan mengirim teks struk langsung ke printer Bluetooth Classic yang sudah dipasangkan, termasuk printer ESC/POS seperti RPP02N.

## Build

GitHub Actions: `.github/workflows/build.yml`

Artifact: `UsahoDen-v8.57-Bluetooth-Native-debug.apk`

## Bluetooth

1. Pasangkan RPP02N terlebih dahulu melalui pengaturan Bluetooth Android.
2. Buka UsahoDen > Pengaturan Printer > Bluetooth.
3. Pilih printer yang sudah dipasangkan.
4. Tombol Print Struk memakai native Android Bluetooth bridge, bukan Android Print Service.

## Catatan

Koneksi menggunakan Bluetooth Classic RFCOMM SPP UUID standar ESC/POS. Printer harus sudah paired di Android. Jika printer memakai profil/UUID khusus, bridge dapat disesuaikan.
