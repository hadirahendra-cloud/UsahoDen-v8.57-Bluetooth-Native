package com.usahoden.app;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.net.Uri;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.content.ClipData;
import java.io.OutputStream;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Toast;

import org.json.JSONArray;

import java.io.ByteArrayInputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends Activity {
    private WebView webView;
    private BluetoothAdapter adapter;
    private static final int REQ_BT = 701;
    private static final int REQ_BACKUP_FOLDER = 702;
    private static final int REQ_PRODUCT_IMAGE = 703;
    private android.webkit.ValueCallback<android.net.Uri[]> pendingFileCallback;
    private String pendingBackupJson = null;
    private String pendingBackupName = "UsahoDen-Backup.json";
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        adapter = BluetoothAdapter.getDefaultAdapter();

        // Android 15 / target 35 uses edge-to-edge by default.  Do NOT let the
        // WebView occupy the physical system-bar areas.  Instead the WebView
        // itself is laid out between the status bar and navigation bar.
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        }
        getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);
        getWindow().setNavigationBarColor(android.graphics.Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(0);

        android.widget.FrameLayout root = new android.widget.FrameLayout(this);
        root.setBackgroundColor(android.graphics.Color.WHITE);

        webView = new WebView(this);
        android.widget.FrameLayout.LayoutParams webLp =
                new android.widget.FrameLayout.LayoutParams(
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT);
        root.addView(webView, webLp);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, android.webkit.ValueCallback<android.net.Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(null);
                pendingFileCallback = filePathCallback;
                try {
                    // Respect the HTML input's accept types. The old implementation
                    // always forced image/*, so Restore Data could not show JSON backups.
                    String mimeType = "*/*";
                    java.util.ArrayList<String> extraMimeTypes = new java.util.ArrayList<>();
                    String[] acceptTypes = fileChooserParams.getAcceptTypes();
                    if (acceptTypes != null) {
                        for (String accepted : acceptTypes) {
                            if (accepted == null) continue;
                            accepted = accepted.trim().toLowerCase(java.util.Locale.ROOT);
                            if (accepted.isEmpty()) continue;
                            if (accepted.startsWith("image/")) {
                                mimeType = "image/*";
                                extraMimeTypes.clear();
                                break;
                            }
                            if (accepted.contains("json") || accepted.endsWith(".json")) {
                                mimeType = "*/*";
                                if (!extraMimeTypes.contains("application/json")) extraMimeTypes.add("application/json");
                                if (!extraMimeTypes.contains("text/json")) extraMimeTypes.add("text/json");
                            } else if (accepted.contains("/") && !accepted.equals("*/*")) {
                                if (mimeType.equals("*/*")) mimeType = accepted;
                            }
                        }
                    }
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(mimeType);
                    if (!extraMimeTypes.isEmpty()) {
                        intent.putExtra(Intent.EXTRA_MIME_TYPES, extraMimeTypes.toArray(new String[0]));
                    }
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, fileChooserParams.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivityForResult(intent, REQ_PRODUCT_IMAGE);
                    return true;
                } catch (Exception e) {
                    pendingFileCallback = null;
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new NativeBridge(), "UsahoDenNative");

        // Use margins rather than WebView padding. This is important because
        // the UsahoDen HTML has fixed/sticky header elements; padding can still
        // allow those elements to draw underneath Android system bars.
        webView.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = 0, bottom = 0, left = 0, right = 0;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(
                        WindowInsets.Type.statusBars()
                                | WindowInsets.Type.navigationBars()
                                | WindowInsets.Type.displayCutout());
                top = bars.top;
                bottom = bars.bottom;
                left = bars.left;
                right = bars.right;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
                left = insets.getSystemWindowInsetLeft();
                right = insets.getSystemWindowInsetRight();
            }

            android.widget.FrameLayout.LayoutParams lp =
                    (android.widget.FrameLayout.LayoutParams) v.getLayoutParams();
            if (lp.topMargin != top || lp.bottomMargin != bottom ||
                    lp.leftMargin != left || lp.rightMargin != right) {
                lp.topMargin = top;
                lp.bottomMargin = bottom;
                lp.leftMargin = left;
                lp.rightMargin = right;
                v.setLayoutParams(lp);
            }
            return insets;
        });

        setContentView(root);

        // Splash screen matching the approved RangMudo Jr. design.
        final android.widget.LinearLayout splash = new android.widget.LinearLayout(this);
        splash.setOrientation(android.widget.LinearLayout.VERTICAL);
        splash.setGravity(android.view.Gravity.CENTER);
        splash.setBackgroundColor(android.graphics.Color.WHITE);
        splash.setPadding(24, 24, 24, 24);

        android.widget.ImageView splashLogo = new android.widget.ImageView(this);
        splashLogo.setImageResource(com.usahoden.app.R.drawable.splash_logo);
        splashLogo.setScaleType(android.widget.ImageView.ScaleType.CENTER_INSIDE);
        android.widget.LinearLayout.LayoutParams logoLp =
                new android.widget.LinearLayout.LayoutParams(
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT, 250);
        logoLp.bottomMargin = 12;
        splash.addView(splashLogo, logoLp);

        android.widget.TextView splashTitle = new android.widget.TextView(this);
        splashTitle.setText("UsahoDen");
        splashTitle.setTextColor(android.graphics.Color.rgb(18, 35, 63));
        splashTitle.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 42);
        splashTitle.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        splashTitle.setGravity(android.view.Gravity.CENTER);
        splash.addView(splashTitle);

        android.widget.TextView splashSubtitle = new android.widget.TextView(this);
        splashSubtitle.setText("Kasir & Manajemen Toko");
        splashSubtitle.setTextColor(android.graphics.Color.rgb(112, 124, 145));
        splashSubtitle.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 24);
        splashSubtitle.setGravity(android.view.Gravity.CENTER);
        android.widget.LinearLayout.LayoutParams subLp =
                new android.widget.LinearLayout.LayoutParams(
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                        android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        subLp.topMargin = 8;
        splash.addView(splashSubtitle, subLp);

        android.widget.TextView splashBrand = new android.widget.TextView(this);
        splashBrand.setText("RangMudo Jr.");
        splashBrand.setTextColor(android.graphics.Color.rgb(0, 142, 213));
        splashBrand.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 23);
        splashBrand.setGravity(android.view.Gravity.CENTER);
        android.widget.LinearLayout.LayoutParams brandLp =
                new android.widget.LinearLayout.LayoutParams(
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                        android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        brandLp.topMargin = 28;
        splash.addView(splashBrand, brandLp);

        root.addView(splash, new android.widget.FrameLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.MATCH_PARENT));

        requestBluetoothPermission();
        webView.loadUrl("file:///android_asset/index.html");

        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
            root.setBackgroundColor(android.graphics.Color.rgb(0, 174, 239));
            splash.animate().alpha(0f).setDuration(220).withEndAction(() -> {
                root.removeView(splash);
                getWindow().setNavigationBarColor(android.graphics.Color.BLACK);
                if (Build.VERSION.SDK_INT >= 26) {
                    getWindow().getDecorView().setSystemUiVisibility(0);
                }
            }).start();
        }, 3000);
    }

    private void requestBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, REQ_BT);
        }
    }

    private boolean hasConnectPermission() {
        return Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private List<BluetoothDevice> pairedPrinters() {
        List<BluetoothDevice> out = new ArrayList<>();
        if (adapter == null || !hasConnectPermission()) return out;
        try {
            for (BluetoothDevice d : adapter.getBondedDevices()) {
                String n = d.getName();
                if (n != null && !n.trim().isEmpty()) out.add(d);
            }
        } catch (SecurityException ignored) {}
        return out;
    }

    public class NativeBridge {
        @JavascriptInterface public String getPairedPrinters() {
            JSONArray a = new JSONArray();
            for (BluetoothDevice d : pairedPrinters()) {
                try { a.put(d.getName()); } catch (Exception ignored) {}
            }
            return a.toString();
        }

        @JavascriptInterface public boolean isBluetoothReady() {
            return adapter != null && adapter.isEnabled() && hasConnectPermission();
        }

        @JavascriptInterface public void printText(final String text) {
            runOnUiThread(() -> new Thread(() -> doPrint(text == null ? "" : text, "")).start());
        }

        @JavascriptInterface public void shareReceiptText(final String text) {
            runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_SUBJECT, "Nota Digital RangMudo Jr.");
                    send.putExtra(Intent.EXTRA_TEXT, text == null ? "Nota RangMudo Jr." : text);
                    startActivity(Intent.createChooser(send, "Bagikan Nota Digital"));
                } catch (Exception e) {
                    toast("Tidak dapat membuka pilihan berbagi");
                }
            });
        }

        @JavascriptInterface public void shareReceiptImage(final String base64Png, final String fileName, final String caption) {
            runOnUiThread(() -> new Thread(() -> {
                Uri imageUri = null;
                try {
                    byte[] bytes = Base64.decode(base64Png, Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    if (bitmap == null) throw new IllegalArgumentException("Gambar nota tidak valid");
                    String safeName = (fileName == null || fileName.trim().isEmpty()) ? "Nota_UsahoDen.png" : fileName.replaceAll("[^a-zA-Z0-9._-]", "_");
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/UsahoDen");
                        values.put(MediaStore.Images.Media.IS_PENDING, 1);
                    }
                    imageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (imageUri == null) throw new IllegalStateException("Tidak dapat membuat file gambar");
                    try (OutputStream out = getContentResolver().openOutputStream(imageUri)) {
                        if (out == null) throw new IllegalStateException("Tidak dapat menyimpan gambar");
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                        out.flush();
                    }
                    bitmap.recycle();
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues done = new ContentValues(); done.put(MediaStore.Images.Media.IS_PENDING, 0);
                        getContentResolver().update(imageUri, done, null, null);
                    }
                    Uri finalUri = imageUri;
                    runOnUiThread(() -> {
                        try {
                            Intent send = new Intent(Intent.ACTION_SEND);
                            send.setType("image/png");
                            send.putExtra(Intent.EXTRA_SUBJECT, "Nota Digital RangMudo Jr.");
                            send.putExtra(Intent.EXTRA_TEXT, caption == null || caption.trim().isEmpty() ? "Nota penjualan RangMudo Jr. - Semoga Berkah" : caption);
                            send.putExtra(Intent.EXTRA_STREAM, finalUri);
                            send.setClipData(ClipData.newUri(getContentResolver(), "Gambar Nota", finalUri));
                            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            startActivity(Intent.createChooser(send, "Bagikan Gambar Nota"));
                        } catch (Exception e) { toast("Gagal membuka pilihan berbagi gambar nota"); }
                    });
                } catch (Exception e) {
                    if (imageUri != null) { try { getContentResolver().delete(imageUri, null, null); } catch (Exception ignored) {} }
                    toast("Gagal membuat gambar nota: " + e.getMessage());
                }
            }).start());
        }

        @JavascriptInterface public void printTextToPrinter(final String text, final String printerName) {
            runOnUiThread(() -> new Thread(() -> doPrint(text == null ? "" : text, printerName == null ? "" : printerName)).start());
        }

        @JavascriptInterface public void backupDataToFolder(final String json, final String fileName) {
            runOnUiThread(() -> {
                pendingBackupJson = json == null ? "{}" : json;
                pendingBackupName = (fileName == null || fileName.trim().isEmpty()) ? "UsahoDen-Backup.json" : fileName;
                try {
                    // ACTION_CREATE_DOCUMENT lets the user choose the destination folder
                    // and creates the backup file there directly.
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, pendingBackupName);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(intent, REQ_BACKUP_FOLDER);
                } catch (Exception e) {
                    toast("Pemilih folder tidak tersedia");
                }
            });
        }

        @JavascriptInterface public void showMessage(final String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }
    }

    private void doPrint(String text, String printerName) {
        if (adapter == null) { toast("Bluetooth tidak tersedia"); return; }
        if (!hasConnectPermission()) { toast("Izin Bluetooth belum diberikan"); return; }
        if (!adapter.isEnabled()) { toast("Aktifkan Bluetooth terlebih dahulu"); return; }
        List<BluetoothDevice> devices = pairedPrinters();
        if (devices.isEmpty()) { toast("Belum ada printer Bluetooth yang dipasangkan"); return; }
        BluetoothDevice chosen = devices.get(0);
        if (printerName != null && !printerName.trim().isEmpty()) {
            for (BluetoothDevice d : devices) if (printerName.equals(d.getName())) { chosen = d; break; }
        }
        BluetoothSocket socket = null;
        try {
            socket = chosen.createRfcommSocketToServiceRecord(SPP_UUID);
            socket.connect();
            OutputStream out = socket.getOutputStream();
            out.write(new byte[]{0x1B,0x40});
            byte[] data;
            try { data = text.replace("\r\n","\n").getBytes(Charset.forName("windows-1252")); }
            catch (Exception e) { data = text.getBytes(); }
            out.write(data);
            out.write(new byte[]{0x0A,0x0A,0x0A});
            out.flush();
            toast("Struk dikirim ke " + chosen.getName());
        } catch (Exception e) {
            toast("Gagal terhubung ke " + chosen.getName() + ". Pastikan printer sudah dipasangkan.");
        } finally {
            if (socket != null) try { socket.close(); } catch (Exception ignored) {}
        }
    }

    private void toast(String s) { runOnUiThread(() -> Toast.makeText(MainActivity.this, s, Toast.LENGTH_LONG).show()); }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PRODUCT_IMAGE) {
            if (pendingFileCallback != null) {
                android.net.Uri[] results = null;
                if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                    results = new android.net.Uri[]{data.getData()};
                }
                pendingFileCallback.onReceiveValue(results);
                pendingFileCallback = null;
            }
            return;
        }
        if (requestCode != REQ_BACKUP_FOLDER) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            pendingBackupJson = null;
            toast("Backup dibatalkan");
            return;
        }
        Uri fileUri = data.getData();
        try {
            try {
                getContentResolver().takePersistableUriPermission(
                        fileUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION |
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } catch (Exception ignored) {}

            try (OutputStream out = getContentResolver().openOutputStream(fileUri, "w")) {
                if (out == null) throw new Exception("Gagal membuka file");
                out.write((pendingBackupJson == null ? "{}" : pendingBackupJson)
                        .getBytes(java.nio.charset.StandardCharsets.UTF_8));
                out.flush();
            }

            toast("Backup tersimpan: " + pendingBackupName);
        } catch (Exception e) {
            toast("Gagal menyimpan backup");
        } finally {
            pendingBackupJson = null;
            pendingBackupName = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
