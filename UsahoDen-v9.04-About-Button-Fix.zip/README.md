# UsahoDen v9.01 - RangMudo Jr Full Customer Names

Perubahan: nama customer dan nama rumah makan di daftar Customer ditampilkan utuh, tanpa elipsis/titik-titik. Teks panjang boleh membungkus ke baris berikutnya.
