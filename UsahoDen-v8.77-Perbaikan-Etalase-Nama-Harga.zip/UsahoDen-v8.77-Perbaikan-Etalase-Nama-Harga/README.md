# UsahoDen v8.76 — Etalase dan Pintasan Penjualan

Perubahan:
- Tombol kembali universal tidak ditampilkan pada halaman Etalase saja.
- Ikon keranjang pada bar Daftar Barang di Etalase menjadi pintasan langsung ke halaman Penjualan.
- Tombol kembali universal tetap tersedia pada halaman lain sesuai versi sebelumnya.

Source Android berada pada folder `app/`.


Perubahan v8.76: header Etalase "Daftar Barang" dan pintasan Penjualan tetap terlihat; hanya daftar produk yang dapat digulir.
