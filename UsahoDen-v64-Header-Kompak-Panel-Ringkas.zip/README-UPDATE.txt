UsahoDen v63 — Kasir 3 halaman + header tetap
=====================================================================

Yang dipertahankan:
- applicationId com.tokoku.app
- index.html asli beserta localStorage database `tokoku_db`
- fungsi produk/pelanggan, harga khusus pelanggan, saveSale, cicilan/piutang, nota, WhatsApp image/text, backup, printer, dan laporan
- MainActivity.java serta native bridges yang ada di source v60
- versionCode dinaikkan ke 63

Perubahan UI:
- Kasir memakai data db dan cart asli: halaman Kasir ringkas; Pilih Produk membuka halaman produk tersendiri; pilih produk membuka formulir Tambah Belanja; Simpan memasukkan produk ke tabel keranjang; tombol +/- jumlah, total, Bayar, Batalkan tetap tersedia. Header tetap di bagian atas.
- Riwayat menampilkan daftar pelanggan lalu transaksi masing-masing.
- Tidak memakai data demo prototype sebagai database. Data contoh dari file prototype tidak dimasukkan.

Sebelum build:
1. Pastikan source ini ada di repository GitHub yang private.
2. GitHub > Settings > Secrets and variables > Actions, buat:
   TOKOKU_KEYSTORE_BASE64 = Base64 satu baris dari usaho-den-v61-permanent.jks
   TOKOKU_KEYSTORE_PASSWORD = password keystore permanen
   TOKOKU_KEY_ALIAS = usahoden
   TOKOKU_KEY_PASSWORD = password private key (bila sama, isi password keystore yang sama)
3. Keystore harus file yang sama persis dengan APK v61. Kami mencocokkan fingerprint sertifikat keystore dengan sertifikat pada UsahoDen-v61-Permanen.apk: SHA-256 B2:DE:C6:F8:2F:BE:DE:17:6C:64:CE:4D:D0:40:3C:A3:AD:D2:6B:DF:6F:C1:60:25:AE:CC:E9:20:AF:BE:35:95.
4. Upload semua isi ZIP ini ke root repository (ekstrak ZIP terlebih dahulu; jangan upload ZIP sebagai satu file).
5. Actions > Build UsahoDen v62 Update > Run workflow.
6. Unduh artifact UsahoDen-v62-Update-Signed dan pasang di atas APK v61 tanpa uninstall, setelah build sukses.

Penting:
- Keystore tidak dimasukkan ke dalam ZIP.
- Jangan menghapus atau mengganti keystore; jangan memakai debug key.
- Versi v62 belum diuji pada perangkat fisik. Lakukan backup dari menu Pengaturan > Backup Data sebelum instal update.
- Walau database key `tokoku_db` dan source lama dipertahankan, selalu uji pada salinan/backup terlebih dahulu. Android biasanya mempertahankan app data saat update in-place, tetapi tidak ada jaminan bila aplikasi sebelumnya sudah memiliki data corruption atau perubahan storage behavior.
