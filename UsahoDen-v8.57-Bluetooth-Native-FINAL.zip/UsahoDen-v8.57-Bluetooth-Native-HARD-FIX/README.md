# UsahoDen v8.57 — Bluetooth Native

Project Android native untuk UsahoDen.

- `index.html` dimuat dari Android assets, bukan `content://` browser.
- `Print Struk` memakai bridge `AndroidBluetooth`.
- Tidak memakai `window.print()` sebagai fallback.
- Target Android 35.
- Bluetooth Classic SPP/RFCOMM untuk printer seperti RPP02N.

## Build GitHub Actions
1. Upload seluruh isi project ini ke repository GitHub.
2. Buka **Actions**.
3. Pilih **Build UsahoDen v8.57 Bluetooth Native**.
4. Tekan **Run workflow**.
5. Setelah selesai, buka **Artifacts** dan download `UsahoDen-v8.57-Bluetooth-Native`.
6. Ekstrak ZIP artifact dan instal APK.

Jangan membuka `app/src/main/assets/index.html` langsung. Untuk Bluetooth Native harus menjalankan APK hasil build.
