# UsahoDen v8.68 – Nota Digital Gambar FIX

Perbaikan: menu Nota Digital sekarang menyediakan pilihan berbagi sebagai gambar PNG atau teks. Gambar nota dibuat dari rincian transaksi yang sedang terbuka, disimpan ke Pictures/UsahoDen, lalu dibuka melalui menu berbagi Android. Print Struk tetap menggunakan jembatan printer Bluetooth native.

Build melalui GitHub Actions menggunakan Gradle 8.7 dan Android SDK 35.
