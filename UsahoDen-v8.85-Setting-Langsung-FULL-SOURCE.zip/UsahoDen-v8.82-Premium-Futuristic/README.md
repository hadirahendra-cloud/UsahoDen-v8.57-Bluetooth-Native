UsahoDen v8.82 Premium Futuristic

Basis source: v8.81 Etalase Nama-Harga Rapi. Perubahan ini memodernisasi CSS tampilan dan menaikkan versionName/versionCode, dengan mempertahankan HTML/JavaScript dan fitur yang ada. Build APK melalui GitHub Actions. Prototipe index.html terpisah tidak menggantikan fungsi aplikasi.
