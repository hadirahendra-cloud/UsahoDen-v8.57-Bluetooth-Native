UsahoDen v8.60 - Bluetooth Native + latest HTML functions


## v8.65 Riwayat Transaksi Customer
- Daftar customer menampilkan nama rumah makan tanpa jumlah transaksi.
- Pilih customer untuk melihat transaksi.
- Pilih transaksi untuk membuka menu Buka Transaksi / Hapus Transaksi.
- Hapus transaksi meminta konfirmasi terlebih dahulu.
- Buka Transaksi menampilkan rincian item dan tanggal transaksi lama dalam halaman Penjualan.
