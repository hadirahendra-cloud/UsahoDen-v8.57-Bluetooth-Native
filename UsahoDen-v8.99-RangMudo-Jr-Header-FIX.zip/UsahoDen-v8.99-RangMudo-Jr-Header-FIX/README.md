# UsahoDen v8.99 — RangMudo Jr Header FIX

Perubahan: judul pada header aplikasi dan judul navigasi samping menjadi **RangMudo Jr** dengan huruf sans-serif biasa. Logo, warna, fitur, dan layout lainnya dipertahankan.

Build APK melalui GitHub Actions menggunakan file workflow terpisah `UsahoDen-v8.99-build-copy-paste.yml`.
